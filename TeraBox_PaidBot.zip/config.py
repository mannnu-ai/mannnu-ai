API_ID = 12345678  # Replace with your API ID
API_HASH = "your_api_hash_here"  # Replace with your API HASH
BOT_TOKEN = "7911460719:AAHjIQ5EAlP49uMEGVrNSVZMJw0MW6m5EMg"
ADMIN_ID = 6124538766
RAZORPAY_LINK = "https://razorpay.me/@personalbot?amount=rZC5NMufSVtgb9QV3szYxw%3D%3D"
BACKEND_BOT = "@TeraBoxBestBot"